package com.example.kachat.sample.model.message;

public enum Status {
    JOIN,
    MESSAGE,
    LEAVE
}
