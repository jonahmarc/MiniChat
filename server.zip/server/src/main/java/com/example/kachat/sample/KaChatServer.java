package com.example.kachat.sample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KaChatServer {

	public static void main(String[] args) {
		SpringApplication.run(KaChatServer.class, args);
	}

}
