package com.example.kachat.sample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KaChatServerTests {

	@Test
	void contextLoads() {
	}

}
